package nl.xservices.plugins;

public class FileProvider extends androidx.core.content.FileProvider {
}